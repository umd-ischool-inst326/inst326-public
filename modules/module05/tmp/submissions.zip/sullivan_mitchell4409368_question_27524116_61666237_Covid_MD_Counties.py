

import pandas as pd
import matplotlib
df = pd.read_csv('MD_COVID19_TotalVaccinationsCountyFirstandSecondDose.numbers')

df.info()

#df.County.value_counts()
